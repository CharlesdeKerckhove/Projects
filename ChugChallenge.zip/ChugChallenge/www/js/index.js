var NeverBtn = document.getElementById("NeverBtn");
var ChugBtn = document.getElementById("ChugBtn");
var EroBtn = document.getElementById("EroBtn");
var ParaBtn = document.getElementById("ParaBtn");

NeverBtn.addEventListener('click', function(){
                          window.location.href='Never.html'
                          });
ChugBtn.addEventListener('click', function(){
                          window.location.href='ChugChallenge.html'
                          });
EroBtn.addEventListener('click', function(){
                          window.location.href='EndGame.html'
                          });
ParaBtn.addEventListener('click', function(){
                          window.location.href='Paranoia.html'
                          });
